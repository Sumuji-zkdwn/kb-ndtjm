#!/usr/bin/env python3
"""Small, independent and auditable GF(2^12) tower-inverse prototype.

The bilinear tables and tower basis are attributed to andigu/uncompute
(Apache-2.0): tasks/dqi-reed-solomon/circuits/discovered/constants.json.
This is not a Kaggle submission or verified Qualtran circuit.
"""
import argparse, json, random, collections
from pathlib import Path

POLY = 0x10eb
B = 12
KT6 = [
 [[0,1,2,5],[0,1,2,5],[3]],
 [[1,2,3,5],[1,2,3,5],[0,2,3,4,5]],
 [[0,3],[0,3],[0,2,4,5]],
 [[0,4,5],[0,4,5],[0]],
 [[3],[3],[1,2,3]],
 [[0,3,4,5],[0,3,4,5],[0,1,2,3]],
 [[0,2,3,5],[0,2,3,5],[2,3]],
 [[2,4,5],[2,4,5],[3,4]],
 [[0,3,4],[0,3,4],[2,4]],
 [[0,1,3,4,5],[0,1,3,4,5],[1,3]],
 [[1,4],[1,4],[1,3,5]],
 [[0,3,5],[0,3,5],[5]],
 [[2,3,5],[2,3,5],[0,4]],
 [[1,3,5],[1,3,5],[0,1,2,5]],
 [[1,2],[1,2],[1,2,4,5]]
]
KT3 = [
 [[0],[0],[0,1,2]],[[1],[1],[0,2]],[[2],[2],[0]],
 [[0,1],[0,1],[1]],[[1,2],[1,2],[0,1]],[[0,2],[0,2],[2]]
]
CUBE3Q = [[[1,2,6],[1,4,2],[2,4,1]],[7,2,4]]
LIN = {
 "E12":[1,2677,1970,228,566,1180,2041,919,3758,2733,3851,1630],
 "A0ROWS":[1217,456,680,912,508,3032],
 "A1ROWS":[1386,2892,742,1696,3470,1906],
 "LNROWS":[1769,472,320,3540,3998,604],
 "SQ3R":[1,4,6],
 "LMROWS":[41,52,14]
}
PHI_COLUMNS = [1,52,1296,1074,1583,3521,1819,3108,729,3181,3661,295]

def change_to_google_basis():
    '''Absorb public->Google field isomorphism into linear operand/output maps.'''
    global LIN, POLY, STAGES
    def phi(pub):
        v=0
        for j in range(12):
            if (pub>>j)&1:v^=PHI_COLUMNS[j]
        return v
    inv=[-1]*4096
    for pub in range(4096):
        google=phi(pub)
        assert inv[google] == -1
        inv[google]=pub
    assert all(t>=0 for t in inv)
    inv_rows=[]
    for j in range(12):
        inv_rows.append(sum((((inv[1<<k]>>j)&1)<<k) for k in range(12)))
    def compose_row(row_pub):
        row=0
        for j in range(12):
            if (row_pub>>j)&1:row^=inv_rows[j]
        return row
    LIN = dict(LIN)
    for key in ('A0ROWS','A1ROWS','LNROWS'):
        LIN[key]=[compose_row(r) for r in LIN[key]]
    LIN['E12']=[phi(x) for x in LIN['E12']]
    POLY=0x1053
    STAGES=stages()

QX=list(range(0,12)); QOUT=list(range(12,24)); QN=list(range(24,30)); QM=list(range(30,33)); QS=list(range(33,36)); QY=list(range(36,42))
PA,PB,PT=42,43,44
TOTAL_Q=45

def support(mask, n):
    return [i for i in range(n) if (mask>>i)&1]

def xor_exprs(*exs):
    ss=set()
    for ex in exs:
        for x in ex:
            if x in ss: ss.remove(x)
            else: ss.add(x)
    return tuple(sorted(ss))

def exprs_from_rows(rows, source):
    return [tuple(source[i] for i in support(row,len(source))) for row in rows]

def exprs_wire(source):
    return [(i,) for i in source]

def masked_expr(spec, indices):
    return xor_exprs(*(spec[i] for i in indices))

def mult_terms(KT, A, B, targets, to_target_mask=None):
    r=[]
    for am,bm,tm in KT:
        l=masked_expr(A,am)
        rr=masked_expr(B,bm)
        tar=[targets[i] for i in tm] if to_target_mask is None else [targets[i] for i in support(to_target_mask(tm),len(targets))]
        r.append((l,rr,tuple(tar)))
    return r

def lin_terms(row_masks,src,tg):
    return [(s,tg[i]) for i,mask in enumerate(row_masks) for s in (src[k] for k in support(mask,len(src)))]

def stages():
    a0=exprs_from_rows(LIN['A0ROWS'],QX)
    a1=exprs_from_rows(LIN['A1ROWS'],QX)
    a01=[xor_exprs(x,y) for x,y in zip(a0,a1)]
    r=[]
    r.append(('norm6', QN, mult_terms(KT6,a0,a1,QN),lin_terms(LIN['LNROWS'],QX,QN)))
    r.append(('norm3', QM, mult_terms(KT3,exprs_wire(QN[:3]),exprs_wire(QN[3:]),QM),lin_terms(LIN['LMROWS'],QN,QM)))
    rt=[]
    for am,bm,tm in CUBE3Q[0]:
        rt.append((masked_expr(exprs_wire(QM),support(am,3)),masked_expr(exprs_wire(QM),support(bm,3)),tuple(QS[i] for i in support(tm,3))))
    r.append(('cube3',QS,rt,lin_terms(CUBE3Q[1],QM,QS)))
    n0=exprs_wire(QN[:3]);n1=exprs_wire(QN[3:]);n01=[xor_exprs(x,y) for x,y in zip(n0,n1)]
    m6=exprs_from_rows(LIN['SQ3R'],QS)
    rt=mult_terms(KT3,n01,m6,QY[:3])+mult_terms(KT3,n1,m6,QY[3:])
    r.append(('invert_norm6',QY,rt,[]))
    def basis_mask(Tb,off):
        mask=0
        for j in Tb: mask ^= LIN['E12'][j+off]
        return mask
    rt=mult_terms(KT6,a01,exprs_wire(QY),QOUT,lambda tm:basis_mask(tm,0))
    rt+=mult_terms(KT6,a1,exprs_wire(QY),QOUT,lambda tm:basis_mask(tm,6))
    r.append(('inverse_into_out',QOUT,rt,[]))
    return r

STAGES=stages()
assert [len(st[2]) for st in STAGES]==[15,6,3,12,30]

def gf_mul(a,b):
    z=0
    for _ in range(12):
        if b&1:z ^= a
        b>>=1
        a<<=1
        if a&0x1000:a ^= POLY
    return z

def gf_pow(a,e):
    z=1
    while e:
        if e&1:z=gf_mul(z,a)
        a=gf_mul(a,a);e>>=1
    return z

def parity_of(q, exp):
    z=0
    for j in exp:z^=q[j]
    return z

def arithmetic_inverse(x):
    q=[0]*TOTAL_Q
    for j in QX:q[j]=(x>>j)&1
    for name, tg, prods,lins in STAGES:
        for src,t in lins:q[t]^=q[src]
        for a,b,ts in prods:
            v=parity_of(q,a)&parity_of(q,b)
            if v:
                for t in ts:q[t]^=1
    return sum(q[j]<<(j-12) for j in QOUT)

class Emitter:
    def __init__(self):self.ops=[]
    def emit(self,*op):self.ops.append(op)
    def xor_to(self, source, target):
        for s in source:self.emit('CX',s,target)
    def prod(self,a,b,targets):
        self.xor_to(a,PA);self.xor_to(b,PB)
        self.emit('CCX',PA,PB,PT)
        for t in targets:self.emit('CX',PT,t)
        self.emit('HMR',PT,0);self.emit('CZif',PA,PB,0)
        self.xor_to(reversed(b),PB);self.xor_to(reversed(a),PA)
    def erase_bit(self, target, prods, lins):
        self.emit('HMR',target,0)
        for s,t in lins:
            if t==target:self.emit('Zif',s,0)
        for a,b,ts in prods:
            if target not in ts:continue
            self.xor_to(a,PA);self.xor_to(b,PB)
            self.emit('CZif',PA,PB,0)
            self.xor_to(reversed(b),PB);self.xor_to(reversed(a),PA)
    def build(self):
        for name,tg,prods,lins in STAGES:
            for s,t in lins:self.emit('CX',s,t)
            for a,b,targets in prods:self.prod(a,b,targets)
        for name,tg,prods,lins in reversed(STAGES[:-1]):
            for j in reversed(tg):self.erase_bit(j,prods,lins)
        return self.ops

def simulate(ops,x,y,seed,fixed_m=None):
    rng=random.Random(seed);q=[0]*TOTAL_Q; b=[0];phase=0
    for i in QX:q[i]=(x>>i)&1
    for i in QOUT:q[i]=(y>>(i-12))&1
    for op in ops:
        kind=op[0]
        if kind=='CX':q[op[2]]^=q[op[1]]
        elif kind=='CCX':q[op[3]]^=q[op[1]]&q[op[2]]
        elif kind=='CZ':phase ^=q[op[1]]&q[op[2]]
        elif kind=='HMR':
            m=rng.getrandbits(1) if fixed_m is None else fixed_m;phase ^= m & q[op[1]]
            q[op[1]]=0;b[op[2]]=m
        elif kind=='CZif':phase ^=b[op[3]]&q[op[1]]&q[op[2]]
        elif kind=='Zif':phase ^=b[op[2]]&q[op[1]]
        else:raise ValueError(op)
    xx=sum(q[j]<<j for j in QX)
    yy=sum(q[j]<<(j-12) for j in QOUT)
    return xx,yy,phase,any(q[j] for j in range(24,TOTAL_Q))

def kmx_str(ops):
    lines=['# 66-CCX GF(2^12) tower inverse; public-basis polynomial 0x10eb',
           '# Input q0..11, output XOR target q12..23; q24..44 scratch; b0 measurement',
           '# Standalone instructions only; official register schema and parser validation pending.']
    for v in ops:
        k=v[0]
        if k in ('CX','CZ','CCX'):lines.append(k+' '+' '.join('q'+str(i) for i in v[1:]))
        elif k=='HMR':lines.append('HMR q'+str(v[1])+' b'+str(v[2]))
        elif k in ('CZif','Zif'):
            lines.append(k[:-2]+' '+' '.join('q'+str(i) for i in v[1:-1])+' if b'+str(v[-1]))
        else:raise ValueError(v)
    return '\n'.join(lines)+'\n'

def main():
    p=argparse.ArgumentParser();p.add_argument('--outdir',default='/mnt/data/tower_inverse66_probe');p.add_argument('--shots',type=int,default=200);p.add_argument('--basis',choices=['public','google'],default='google');p.add_argument('--all-trajectories',action='store_true')
    args=p.parse_args();out=Path(args.outdir);out.mkdir(parents=True,exist_ok=True)
    if args.basis=='google':change_to_google_basis()
    arithmetic_bad=[]
    for x in range(4096):
        actual=arithmetic_inverse(x)
        ideal=gf_pow(x,4094) if x else 0
        if actual!=ideal:arithmetic_bad.append((x,actual,ideal))
    e=Emitter();ops=e.build();counts=collections.Counter(o[0] for o in ops)
    assert counts['CCX']==66 and len(ops)>0
    rg=random.Random(1773);shots=[(x,rg.getrandbits(12),rg.getrandbits(32)) for x in [0,1,2,17,4095] for _ in range(5)]
    shots += [(rg.randrange(4096),rg.getrandbits(12),rg.getrandbits(32)) for _ in range(args.shots)]
    if args.all_trajectories:
        shots += [(x,rg.getrandbits(12),rg.getrandbits(32)) for x in range(4096)]
    circuit_bad=[]
    for x,y,seed in shots:
        actual=simulate(ops,x,y,seed);expected=(x,y^arithmetic_inverse(x),0,False)
        if actual!=expected:circuit_bad.append((x,y,seed,actual,expected))
    data={'source':'andigu/uncompute public discovered DQI constants (Apache-2.0)','basis':args.basis,'polynomial':hex(POLY),'total_field_inputs':4096,'arithmetic_failures':len(arithmetic_bad),'trajectory_shots':len(shots),'trajectory_failures':len(circuit_bad),'qubits':TOTAL_Q,'qubit_layout':'x[0:12], out[12:24], scratch[24:45]','total_ops':len(ops),'gates':dict(counts),'toffolis':counts['CCX'],'mbuc_note':'Scratch erased using X basis measurements and conditional Clifford phase correction; no additional CCX counted','sample_error':(arithmetic_bad[:1] or circuit_bad[:1])}
    (out/f'inverse66_{args.basis}.kmx').write_text(kmx_str(ops).replace('public-basis polynomial 0x10eb',f'{args.basis} basis polynomial {hex(POLY)}'));(out/f'verification_{args.basis}.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
    print(json.dumps(data,ensure_ascii=False,indent=2))
    if arithmetic_bad or circuit_bad:raise SystemExit(1)
if __name__=='__main__':main()
