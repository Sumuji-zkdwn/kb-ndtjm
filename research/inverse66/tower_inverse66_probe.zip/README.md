# DQI: 既存逆元計算だけを交換する 66-Toffoli 局所回路

2026年10月25日。公開高速 Berlekamp–Massey 復号器全体を新規に移植する代わりに、Google Quantum AI の既存 DQI 基準回路で使用する GF(2^12) 逆元計算器を交換する構想。

## 実際に生成・検査できたもの

- `inverse66_google.kmx`: Google 指定の有限体多項式 `0x1053 = t^12+t^6+t^4+t+1` に対する、逆元計算ゲート列（2,704命令）。
- `inverse66_public.kmx`: 公開高速回路が用いる `0x10eb` 版（2,720命令）。
- `tower_inverse66.py`: 66 個の非線形積の再生成、静的なゲート列出力、独立した古典軌跡シミュレーション、全4096入力の整数有限体演算との照合。外部Python依存なし。
- `verification_google.json` / `verification_public.json`: 検査結果。

作用: `|x>|y>|0> -> |x>|y XOR inv(x)>|0>`。`inv(0)=0` とする。

Google版のゲート数: 66 CCX、2,367 CX、84 HMR、140 classical-conditional CZ、47 classical-conditional Z、合計2,704命令。45量子ビットの内訳は入力12、出力12、補助21。測定結果は古典ビット `b0` を逐次再利用する。

- 有限体の全4096入力で算術出力が完全一致: **失敗0**。
- 4241例の測定を含むゲート軌跡で入力、出力、位相、補助ビットの全条件に一致: **失敗0**。
- 加えて、すべてのHMR測定結果を0、すべて1と固定した2通りについて各4096入力を追加検査: **失敗0**。
- すべての量子測定枝を列挙した実験ではない。ただし回路生成規則は各HMRに対して条件付きZ/CZで符号キックバックを相殺する局所恒等式を使う。

## ゲート数の根拠

公開コードの GF(2^12)=GF(64)(t), GF(64)=GF(8)(s) という塔体表示に基づく。各2次拡大のnormを下位体へ押し出し、GF(8) の逆元は `M^-1 = (M^3)^2` とする。GF(8) の立方は 3 個の二次積＋線形項。計算段階ごとの非線形積は

| 段階 | AND (CCX) |
|---|---:|
| GF(4096)→GF(64) norm | 15 |
| GF(64)→GF(8) norm | 6 |
| GF(8) の立方 | 3 |
| GF(64) norm の逆元復元 | 12 |
| GF(4096) の逆元復元 | 30 |
| **合計** | **66** |

計算した中間値はX基底で測定して消去する。各測定の位相キックバックを、入力側の線形パリティおよび二次積のZ/CZ補正で打ち消すため、作業領域の消去に追加CCXを必要としない。係数と塔体基底は公開の `andigu/uncompute` の定数表から採用した。有限体基底の変更は GF(2) 線形演算として入力側の読出し行列と出力側の係数行列に吸収し、追加のCCXを使用していない。

## DQI全体への費用影響（試算であり実測ではない）

Google論文で基準の伊藤-辻井逆元演算は315 Toffoli、各位置の走査には351 Toffoli、位置は4095。基準総計 T=5,725,461、Q=1,893。この逆元を66 Toffoliに置換し、他の処理や失敗率、Qに影響がないと仮定すると、

```
new_T = 5,725,461 - 4095*(315-66) = 4,705,806
DQI improvement = 5,725,461 / 4,705,806 ≈ 1.2167
Total Kaggle score (other tasks unchanged) ≈ 1.06756
```

使用量子ビット数がどう変わるかは**基準回路へ組み込むまで不明**。追加CNOTなどの影響はDQIのToffoli費用では直接数えられないが、回路サイズ・実行時間に影響し得る。

## 未実施・注意

**これは提出可能な `dqi.kmb` ではない。** `inverse66_google.kmx` は局所ゲート列のテキスト候補であり、名前付きDQIシンドロームレジスタ、4,095位置の走査、可変位相マスク等を含まない。現在の環境には Google の配布 `kickmix.so` / `verifiers/` がないため、公式パーサによる読込み、公式DQi検証102,400ショット、全体Q/T計測は**未実施**。ここでのゲート列の意味論は独立Pythonシミュレータで検証した。

次の実装ではGoogleの元のDQI生成コード内で `inverse(x) -> out` の部分をこの演算器へ交換し、元の可変位相の制御とシンドローム処理は変更しない。作業ビットを割り当て／解放する際は、元のレジスタ管理と重ならないようにする。合格と実測費用を見てから `submission.zip` の `dqi.kmb` を置換する。

## 再実行

```
python tower_inverse66.py --basis google --shots 300 --all-trajectories --outdir ./probe
python tower_inverse66.py --basis public --shots 300 --outdir ./probe
```

## 出典と権利

- Google Quantum AI, *Leveraging verifiable structure in quantum circuits to find more efficient compilations with agentic AI* (2026), Benchmark II.
- Andi Gu et al., `andigu/uncompute`, `tasks/dqi-reed-solomon/circuits/discovered/circuit.py` および `constants.json`。 https://github.com/andigu/uncompute (Apache License 2.0)
- 有限体基底の対応は会話中の既存検証 `dqi_existing_model_reuse` による。

同梱Pythonの逆元ゲート生成・独立検査実装は本実験で作成。公開定数表を含むため、公開元のApache 2.0ライセンス条件および出典表示に従って利用すること。
